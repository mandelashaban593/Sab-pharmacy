  <div class="well sidebar-nav">
                     <ul class="nav nav-list">
              <li class="active"><a href="#"><i class="icon-dashboard icon-2x"></i> Dashboard </a></li> 
			<li><a href="sales.php?id=cash&invoice=<?php echo $finalcode ?>"><i class="icon-shopping-cart icon-2x"></i> Sales</a>  </li>           
			<li><a href="products.php"><i class="icon-list-alt icon-2"></i> Products</a>                                     </li>
			<li><a href="customer.php"><i class="icon-group icon-2"></i> Customers</a>                                    </li>
			<li><a href="supplier.php"><i class="icon-group icon-2"></i> Suppliers</a>                                    </li>
			<li><a href="purchases.php"><i class="icon-group icon-2"></i> Add Purchases</a>                                    </li>
			<li><a href="purchaseslist.php"><i class="icon-group icon-2"></i> Purchases</a>  </li>
			<li><a href="addassets.php"><i class="icon-group icon-2"></i> Add Assets</a>  </li>
			<li><a href="addliab.php"><i class="icon-group icon-2"></i> Add Liabilities</a>  </li>
			<li><a href="addequity.php"><i class="icon-group icon-2"></i> Add Stock holders Equity</a>  </li>
			<li><a href="general_ledger.php"><i class="icon-group icon-2"></i> General Ledger</a>                                  </li>

			<li><a href="balance_sheet.php"><i class="icon-group icon-2x]"></i> Balance Sheet</a>                                  </li>
			<li><a href="profit_loss.php"><i class="icon-group icon-2x"></i> Profit and Loss Account</a>                                  </li>
			
			<li><a href="salesreport.php?d1=0&d2=0"><i class="icon-bar-chart icon-2x"></i> Sales Report</a>                </li>
			<br><br><br><br><br><br>		
			<li>
			 <div class="hero-unit-clock">
		
			<form name="clock">
			<font color="white">Time: <br></font>&nbsp;<input style="width:150px;" type="submit" class="trans" name="face" value="">
			</form>
			  </div>
			</li>
				</ul>                               
          </div><!--/.well -->
        </div><!--/span-->